from flask import Flask, request, render_template, url_for
import os
from datetime import datetime

app = Flask(__name__)
UPLOAD_DIR = os.path.join("static", "uploads")
os.makedirs(UPLOAD_DIR, exist_ok=True)

@app.route("/")
def index():
    files = sorted(os.listdir(UPLOAD_DIR), reverse=True)
    return render_template("index.html", files=files)

@app.route("/upload", methods=["POST"])
def upload():
    f = request.files["screenshot"]
    filename = datetime.now().strftime("%Y%m%d_%H%M%S.png")
    f.save(os.path.join(UPLOAD_DIR, filename))
    return "OK"

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
